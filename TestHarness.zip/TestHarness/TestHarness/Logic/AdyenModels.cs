﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TestHarness.Logic.FOOOOOBAR
{
    public class MessageHeader
    {
        public string ProtocolVersion { get; set; }
        public string MessageClass { get; set; }
        public string MessageCategory { get; set; }
        public string MessageType { get; set; }
        public string SaleID { get; set; }
        public string ServiceID { get; set; }
        public string POIID { get; set; }
    }

    public class SaleTransactionID
    {
        public string TransactionID { get; set; }
        public DateTime TimeStamp { get; set; }
    }

    public class SaleData
    {
        public SaleTransactionID SaleTransactionID { get; set; }
    }

    public class AmountsReq
    {
        public string Currency { get; set; }
        public double RequestedAmount { get; set; }
    }

    public class PaymentTransaction
    {
        public AmountsReq AmountsReq { get; set; }
    }

    public class PaymentRequest
    {
        public SaleData SaleData { get; set; }
        public PaymentTransaction PaymentTransaction { get; set; }
    }

    public class SaleToPOIRequest
    {
        public MessageHeader MessageHeader { get; set; }
        public PaymentRequest PaymentRequest { get; set; }
    }

    public class RootObject
    {
        public SaleToPOIRequest SaleToPOIRequest { get; set; }
    }
}
