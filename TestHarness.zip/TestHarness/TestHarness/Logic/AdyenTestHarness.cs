﻿using System;
using System.Net;
using System.Text;
using Adyen;
using Adyen.Model.Nexo;
using Adyen.Model.Nexo.Message;
using Adyen.Service;

namespace TestHarness.Logic
{
    class AdyenTestHarness
    {
        // https://ca-test.adyen.com/ca/ca/postfm/manageposterminal.shtml?uniqueTerminalId=P400Plus-275289150&legacy=false&activeTab=network

        public static string AdyenApiKey = "AQElhmfuXNWTK0Qc+iSTl2osteG+TIxILhTa/UUK3AnKEvof+V4xXRDBXVsNvuR83LVYjEgiTGAH-ZCqoeW1arpaQ4VsO6EZ6ziRVEB86FubmPCWD5uGBBUw=-SCH2jRbAHL5YQD9U";
        public static string QAPOIID = "P400Plus-275289160";
        public static string DevPOIID = "P400Plus-275289150";

        public string MakePayment(string posId, string stationId, string currency, decimal amount)
        {
            Client client = new Client(AdyenApiKey, Adyen.Model.Enum.Environment.Test);
            PosPaymentCloudApi service = new PosPaymentCloudApi(client);

            String saleID = stationId;// "YOUR_CASH_REGISTER_ID";
            String POIID = posId;
            String transactionID = DateTime.Now.ToString("hhmmssfff");
            String serviceID = transactionID;// "YOUR_UNIQUE_ATTEMPT_ID";

            SaleToPOIRequest saleToPOIRequest = new SaleToPOIRequest();

            /* Message Header */
            MessageHeader messageHeader = new MessageHeader();
            messageHeader.MessageClass = MessageClassType.Service;
            messageHeader.MessageCategory = MessageCategoryType.Payment;
            messageHeader.MessageType = MessageType.Request;
            messageHeader.SaleID = saleID;
            messageHeader.ServiceID = serviceID;
            messageHeader.POIID = POIID;
            saleToPOIRequest.MessageHeader = messageHeader;

            /* Payment Request */
            PaymentRequest paymentRequest = new PaymentRequest();
            SaleData saleData = new SaleData();
            TransactionIdentification saleTransactionID = new TransactionIdentification();
            saleTransactionID.TransactionID = transactionID;
            saleTransactionID.TimeStamp = DateTime.Now;
            saleData.SaleTransactionID = saleTransactionID;
            paymentRequest.SaleData = saleData;

            /* Payment Transaction */
            PaymentTransaction paymentTransaction = new PaymentTransaction();
            AmountsReq amountsReq = new AmountsReq();
            amountsReq.Currency = currency;
            amountsReq.RequestedAmount = amount;
            paymentTransaction.AmountsReq = amountsReq;

            paymentRequest.PaymentTransaction = paymentTransaction;

            saleToPOIRequest.MessagePayload = paymentRequest;

            WriteToLog($"Sending request {transactionID}");

            SaleToPOIResponse response = service.TerminalApiCloudSync(saleToPOIRequest);

            WriteToLog($"Response received for {transactionID}");

            if (response.MessagePayload is EventNotification)
            {
                string message = String.Empty;

                EventNotification notification = response.MessagePayload as EventNotification;

                switch (notification.EventToNotify)
                {
                    case EventToNotifyType.BeginMaintenance:
                        {
                            break;
                        }
                    case EventToNotifyType.EndMaintenance:
                        {
                            break;
                        }
                    case EventToNotifyType.Shutdown:
                        {
                            break;
                        }
                    case EventToNotifyType.Initialised:
                        {
                            break;
                        }
                    case EventToNotifyType.OutOfOrder:
                        {
                            break;
                        }
                    case EventToNotifyType.Completed:
                        {
                            break;
                        }
                    case EventToNotifyType.Abort:
                        {
                            break;
                        }
                    case EventToNotifyType.SaleWakeUp:
                        {
                            break;
                        }
                    case EventToNotifyType.SaleAdmin:
                        {
                            break;
                        }
                    case EventToNotifyType.CustomerLanguage:
                        {
                            break;
                        }
                    case EventToNotifyType.KeyPressed:
                        {
                            break;
                        }
                    case EventToNotifyType.SecurityAlarm:
                        {
                            break;
                        }
                    case EventToNotifyType.StopAssistance:
                        {
                            break;
                        }
                    case EventToNotifyType.CardInserted:
                        {
                            break;
                        }
                    case EventToNotifyType.CardRemoved:
                        {
                            break;
                        }
                    case EventToNotifyType.Reject:
                        {
                            message = GetNotificationMessage(notification.EventDetails);
                            break;
                        }
                    default:
                        {
                            throw new InvalidOperationException($"Unrecognized EventToNotifyType: {notification.EventToNotify.ToString()}");
                        }
                }

                string errorMessage = $"{notification.EventToNotify}-{message}";

                WriteToLog(errorMessage);

                return errorMessage;
            }
            else if (response.MessagePayload is PaymentResponse)
            {
                PaymentResponse paymentResponse = response.MessagePayload as PaymentResponse;

                string receiptsContent = GetReceiptText(paymentResponse.PaymentReceipt);

                WriteToLog($"\r\n*** Receipt(s) Text ***\r\n{receiptsContent}");

                return receiptsContent;
            }
            else
            {
                throw new InvalidOperationException($"Unrecognized response type: {response.MessagePayload.GetType().FullName}");
            }
        }

        private void WriteToLog(string message)
        {
            Console.WriteLine($"{DateTime.Now}: {message}\r\n");
        }

        private string GetReceiptText(PaymentReceipt[] receipts)
        {
            StringBuilder sb = new StringBuilder();

            for (int i = 0; i < receipts.Length; i++)
            {
                sb.AppendLine($"[ BEGIN RECEIPT {i} ]");
                sb.AppendLine();

                PaymentReceipt receipt = receipts[i];

                for (int l = 0; l < receipt.OutputContent.OutputText.Length; l++)
                {
                    OutputText receiptLine = receipt.OutputContent.OutputText[l];

                    Console.WriteLine(receiptLine.Text);

                    if (receiptLine.Text == "key=filler")
                    {
                        sb.AppendLine();
                    }
                    else
                    {
                        string[] rawReceiptLineText = receiptLine.Text.Split('&');

                        string lineLabel = String.Empty;
                        string lineValue = String.Empty;

                        for (int x = 0; x < rawReceiptLineText.Length; x++)
                        {
                            if (rawReceiptLineText[x].StartsWith("name="))
                            {
                                string rawReceiptLabelText = rawReceiptLineText[x].Substring(5);
                                lineLabel = $"{WebUtility.UrlDecode(rawReceiptLabelText)} ";
                            }
                            if (rawReceiptLineText[x].StartsWith("value="))
                            {
                                string rawReceiptValueText = rawReceiptLineText[x].Substring(6);
                                lineValue = WebUtility.UrlDecode(rawReceiptValueText);
                            }
                        }

                        if (!String.IsNullOrEmpty(lineLabel))
                        {
                            if (receiptLine.EndOfLineFlag.GetValueOrDefault(false))
                            {
                                sb.AppendLine($"{lineLabel}{lineValue}");
                            }
                            else
                            {
                                sb.Append($"{lineLabel}{lineValue}");
                            }
                        }
                    }
                }

                sb.AppendLine();
                sb.AppendLine($"[ END RECEIPT {i} ]");
            }

            return sb.ToString();
        }

        private string GetNotificationMessage(string rawMessage)
        {
            if (!rawMessage.StartsWith("message="))
            {
                return rawMessage;
            }

            return (rawMessage.Substring(8).Replace("+", " "));
        }
    }
}
