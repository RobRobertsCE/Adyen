﻿using System;
using System.Windows.Forms;
using TestHarness.Logic;

namespace TestHarness
{
    public partial class AdyenTestForm : Form
    {
        public AdyenTestForm()
        {
            InitializeComponent();
        }

        private void btnTakePayment_Click(object sender, EventArgs e)
        {
            try
            {
                pnlDetails.Enabled = false;

                AdyenTestHarness harness = new AdyenTestHarness();

                decimal amount = 0;

                if (!decimal.TryParse(txtTransactionAmount.Text, out amount))
                {
                    MessageBox.Show("Couldn't parse transaction amount");
                    return;
                }

                string result = harness.MakePayment(txtTerminalId.Text, txtStation.Text, txtCurrency.Text, amount);

                txtResult.Text += $"{result}\r\n--------------------------------------\r\n";
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
                Console.WriteLine(ex.ToString());
            }

            pnlDetails.Enabled = true;
        }
    }
}
